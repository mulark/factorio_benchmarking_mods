data.raw["recipe"]["iron-plate"].energy_required = 3.5
data.raw["assembling-machine"]["chemical-plant"].crafting_speed = 1.25
data.raw["recipe"]["light-oil-cracking"].energy_required = 3
data.raw["recipe"]["heavy-oil-cracking"].energy_required = 3
