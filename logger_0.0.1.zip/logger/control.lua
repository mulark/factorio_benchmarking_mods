script.on_event(defines.events.on_tick, function(event)
    log(game.tick)
end)
