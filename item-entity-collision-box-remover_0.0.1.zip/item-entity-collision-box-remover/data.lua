data.raw["item-entity"]["item-on-ground"].collision_box =  nil-- {{0,0},{0,0}}
