data.raw["item-entity"]["item-on-ground"].collision_mask = {}
